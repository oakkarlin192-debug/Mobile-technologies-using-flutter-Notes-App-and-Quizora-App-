package com.example.noteapp;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Adapter for the RecyclerView in ViewActivity.
 * Manages the display and interactions of note items.
 */
public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.NoteViewHolder>{
    
    private List<Note> noteList;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    public NoteAdapter (List<Note> list){
        this.noteList = list;
    }

    @NonNull
    @Override
    public NoteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_note, parent, false);
        return new NoteViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NoteViewHolder holder, int position) {
        Note note = noteList.get(position);
        holder.titleText.setText(note.getTitle());
        holder.contentText.setText(note.getContent());

        // Open details on click
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), DetailActivity.class);
            intent.putExtra("title", note.getTitle());
            intent.putExtra("content", note.getContent());
            intent.putExtra("position", note.getId()); // Pass DB ID
            v.getContext().startActivity(intent);
        });

        // Quick delete button
        holder.btnDelete.setOnClickListener(v -> {
            int currentPos = holder.getAdapterPosition();
            if (currentPos != RecyclerView.NO_POSITION) {
                Note noteToDelete = noteList.get(currentPos);
                
                executor.execute(() -> {
                    AppDatabase.getInstance(v.getContext()).noteDao().delete(noteToDelete);
                    // No need to manually remove from list if ViewActivity refreshes onResume
                    // but for smooth UI, we remove it here too
                    ((ViewActivity)v.getContext()).runOnUiThread(() -> {
                        noteList.remove(currentPos);
                        notifyItemRemoved(currentPos);
                        notifyItemRangeChanged(currentPos, noteList.size());
                    });
                });
            }
        });
    }

    @Override
    public int getItemCount() {
        return noteList.size();
    }

    public static class NoteViewHolder extends RecyclerView.ViewHolder{
        TextView titleText;
        TextView contentText;
        ImageButton btnDelete;

        public NoteViewHolder (@NonNull View itemView) {
            super(itemView);
            titleText = itemView.findViewById(R.id.titleText);
            contentText = itemView.findViewById(R.id.contentText);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}
