package com.example.noteapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Activity for viewing full note details and deleting the note.
 */
public class DetailActivity extends AppCompatActivity {

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private AppDatabase db;
    private int noteId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_detail);

        db = AppDatabase.getInstance(this);
        initViews();
    }

    private void initViews() {
        TextView tvTitle = findViewById(R.id.tvDetailTitle);
        TextView tvContent = findViewById(R.id.tvDetailContent);
        Button btnDelete = findViewById(R.id.btnDelete);

        // Get data from Intent
        String title = getIntent().getStringExtra("title");
        String content = getIntent().getStringExtra("content");
        noteId = getIntent().getIntExtra("position", -1); // 'position' was used as ID placeholder

        tvTitle.setText(title);
        tvContent.setText(content);

        btnDelete.setOnClickListener(v -> deleteNote(title, content));

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, 0, systemBars.right, systemBars.bottom);
            findViewById(R.id.headerLayout).setPadding(0, systemBars.top, 0, 0);
            return insets;
        });
    }

    /**
     * Deletes the current note from the database.
     */
    private void deleteNote(String title, String content) {
        executor.execute(() -> {
            // Note: In a real app, we use the unique primary key ID. 
            // Here we recreate a note object for deletion or use ID.
            Note noteToDelete = new Note(title, content);
            noteToDelete.setId(noteId);
            
            db.noteDao().delete(noteToDelete);
            
            runOnUiThread(() -> {
                Toast.makeText(DetailActivity.this, "Note deleted", Toast.LENGTH_SHORT).show();
                finish();
            });
        });
    }
}
