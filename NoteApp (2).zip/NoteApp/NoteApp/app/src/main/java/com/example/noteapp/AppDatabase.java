package com.example.noteapp;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

/**
 * Main Database class for the application using Room.
 * Follows the Singleton pattern to ensure only one instance is active.
 */
@Database(entities = {Note.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    private static AppDatabase instance;

    /**
     * @return The Data Access Object for notes.
     */
    public abstract NoteDao noteDao();

    /**
     * Gets the singleton instance of the AppDatabase.
     * @param context The application context.
     * @return The database instance.
     */
    public static synchronized AppDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(),
                            AppDatabase.class, "note_database")
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return instance;
    }
}
