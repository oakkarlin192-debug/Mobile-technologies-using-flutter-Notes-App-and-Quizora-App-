package com.example.noteapp;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Represents a single Note entity in the database.
 */
@Entity(tableName = "notes_table")
public class Note {

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String title;
    private String content;
    private long timestamp;

    /**
     * Constructor for creating a new Note.
     * @param title   The title of the note.
     * @param content The body text of the note.
     */
    public Note(String title, String content) {
        this.title = title;
        this.content = content;
        this.timestamp = System.currentTimeMillis();
    }

    // Getters and Setters

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
}
