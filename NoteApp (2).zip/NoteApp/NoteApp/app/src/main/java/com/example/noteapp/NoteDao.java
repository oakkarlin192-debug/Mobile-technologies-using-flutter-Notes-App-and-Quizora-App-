package com.example.noteapp;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

/**
 * Data Access Object (DAO) for the notes table.
 * Defines the database operations available.
 */
@Dao
public interface NoteDao {

    @Insert
    void insert(Note note);

    @Update
    void update(Note note);

    @Delete
    void delete(Note note);

    @Query("SELECT * FROM notes_table ORDER BY timestamp DESC")
    List<Note> getAllNotes();

    @Query("SELECT * FROM notes_table WHERE title LIKE :searchQuery OR content LIKE :searchQuery ORDER BY timestamp DESC")
    List<Note> searchNotes(String searchQuery);
}
