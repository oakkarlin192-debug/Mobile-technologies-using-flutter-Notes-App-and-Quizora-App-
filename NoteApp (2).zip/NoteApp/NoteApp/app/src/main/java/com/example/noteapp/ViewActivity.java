package com.example.noteapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Main activity displaying the list of notes.
 * Includes search functionality and database integration.
 */
public class ViewActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    public static NoteAdapter adapter;
    public static List<Note> myNotes = new ArrayList<>();
    private AppDatabase db;
    private TextView tvEmptyState;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_view);

        db = AppDatabase.getInstance(this);
        initViews();
        setupSearch();
        loadNotes("");
    }

    private void initViews() {
        recyclerView = findViewById(R.id.recyclerView);
        tvEmptyState = findViewById(R.id.tvEmptyState);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        
        adapter = new NoteAdapter(myNotes);
        recyclerView.setAdapter(adapter);

        FloatingActionButton fabAdd = findViewById(R.id.fabAdd);
        fabAdd.setOnClickListener(v -> {
            Intent intent = new Intent(ViewActivity.this, AddNoteActivity.class);
            startActivity(intent);
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, 0, systemBars.right, systemBars.bottom);
            findViewById(R.id.headerLayout).setPadding(0, systemBars.top, 0, 0);
            return insets;
        });
    }

    /**
     * Sets up the search bar with a TextWatcher for real-time filtering.
     */
    private void setupSearch() {
        EditText etSearch = findViewById(R.id.etSearch);
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                loadNotes(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    /**
     * Loads notes from the database.
     * @param query Search query to filter notes (optional).
     */
    public void loadNotes(String query) {
        executor.execute(() -> {
            final List<Note> filteredList;
            if (query.isEmpty()) {
                filteredList = db.noteDao().getAllNotes();
            } else {
                filteredList = db.noteDao().searchNotes("%" + query + "%");
            }

            runOnUiThread(() -> {
                myNotes.clear();
                myNotes.addAll(filteredList);
                adapter.notifyDataSetChanged();
                
                // Show/hide empty state message
                tvEmptyState.setVisibility(myNotes.isEmpty() ? View.VISIBLE : View.GONE);
            });
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadNotes(""); // Refresh list when returning to activity
    }
}
